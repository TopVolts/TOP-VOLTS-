<?php
/*
Plugin Name: Orçamentos CW
Plugin URI: http://www.cicloneweb.com.br/
Description: Transforme seu site em um catalogo online. Sistema para captação de orçamentos.
Version: 1.4.0
Author: Ciclone Web
License: GPL version 2 or later - http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
*/

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

function versao_cw(){
	return '1.4.0';
}

function api_cw($array){
	$ch = curl_init('https://cicloneweb.com.br/Api/');
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
	curl_setopt($ch, CURLOPT_POSTFIELDS, $array);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	return json_decode(curl_exec($ch));
}

/* Verifica atualizacao */
function notice_atualizacao() {
	?>
	<div class="notice notice-warning is-dismissible"><p><b>Atenção!</b> Foi lançada uma nova versão do plugin de Orçamento. <b><a href="<?php echo get_option('siteUrl') ?>/wp-admin/edit.php?post_type=produto&page=atualizacao">Clique aqui e atualize</a></b></p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dispensar este aviso.</span></button></div>
	<?php
}
if($_GET['page'] != 'atualizacao'){
	$versao = array('action' => 'pluginOrcamento/verificaVersao');
	$api = api_cw($versao);
	if($api->status == 'success'){
		if($api->ultimaVersao != versao_cw() ){
			add_action( 'admin_notices', 'notice_atualizacao' );
			function scriptAtualiazacao(){
				global $api;
				?>
				<script>
					jQuery(document).ready(function(){
						jQuery('#menu-posts-produto [href="edit.php?post_type=produto&page=atualizacao"]').append(' <span class="update-plugins count-1"><span class="plugin-count">!</span></span>');

						jQuery('<tr class="plugin-update-tr active" id="orcamento-cw-update" data-slug="orcamento-cw"><td colspan="3" class="plugin-update colspanchange"><div class="update-message notice inline notice-warning notice-alt"><p>Há uma nova versão do Orçamentos CW - Versão <b><?php echo $api->ultimaVersao ?></b>. <a href="<?php echo get_option('siteUrl') ?>/wp-admin/edit.php?post_type=produto&page=atualizacao" class="update-link" aria-label="Atualizar Orçamentos CW agora.">Atualize agora</a>.</p></div></td></tr>').insertAfter('[data-plugin="orcamento-cw/orcamento-cw.php"]');		
					});
				</script>
				<?php
			}
			add_action( 'admin_footer', 'scriptAtualiazacao' ); 
		}
	}
}

/* Fim - Verivica atualizacao */

/** Habilita shortcode na sidebar **/
add_filter('widget_text','do_shortcode');

/*** ESTILOS E TEXTOS ***/
function orcamentoConfig($string){
	if(get_option('configOrcamento')){
		$config = unserialize(get_option('configOrcamento'));
		return $config[$string];
	}
}

/** Tabela - Categorias **/
global $wpdb;
$wpdb->get_results("CREATE TABLE IF NOT EXISTS `orcamentos_cw_pedidos` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`nomeCliente` char(80) NOT NULL,
	`emailCliente` char(80) NOT NULL,
	`orcamento` text NOT NULL,
	`produtos` text NOT NULL,
	`data` timestamp NOT NULL,
	PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;");

$wpdb->get_results("CREATE TABLE IF NOT EXISTS `orcamentos_cw_resposta` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`id_orcamento` int(11) NOT NULL,
	`resposta` text NOT NULL,
	`data` timestamp NOT NULL,
	PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;");

$table = $wpdb->get_results("SHOW COLUMNS FROM orcamentos_cw_pedidos");
if($table){
	$existe = false;
	foreach ($table as $colunas) {
		if($colunas->Field == 'produtos'){
			$existe = true;
		}				
	}
}
if(!$existe){
	$wpdb->get_results("ALTER TABLE orcamentos_cw_pedidos ADD produtos text COLLATE 'latin1_swedish_ci' NOT NULL AFTER orcamento");
}

//Verifica se existe pagina "ORCAMENTOS" - se náo, notifica pra acessar
if($_GET['page'] != 'configuracoes-orcamentos-cw'){
	$pageExiste = true;
	query_posts('post_type=page&name=orcamentos');
	if (!have_posts()){ $pageExiste = false; }
	query_posts('post_type=page&name=orcamentos');
	if (!have_posts()){ $pageExiste = false; } 
	if($pageExiste == false){
		function sample_admin_notice_produtos() {
			?>
			<div class="notice notice-error"><p><b>Atenção!</b> <a href="<?php echo get_option('siteUrl') ?>/wp-admin/edit.php?post_type=produto&page=configuracoes-orcamentos-cw">Clique aqui</a> para configurar seus orçamentos.</p></div>
			<?php
		}
		add_action( 'admin_notices', 'sample_admin_notice_produtos' );
	}
}
//FIM Verifica se existe pagina "ORCAMENTOS" - se náo, notifica pra acessar

function submenuProdutoAdmin() {
	add_submenu_page(
		'edit.php?post_type=produto',
		__( 'Configurações - Orçamentos', 'textdomain' ),
		__( 'Configurações', 'textdomain' ),
		'manage_options',
		'configuracoes-orcamentos-cw',
		'requirePageConfig'
	);
	add_submenu_page(
		'edit.php?post_type=produto',
		__( 'Atualização', 'textdomain' ),
		__( 'Atualização', 'textdomain' ),
		'manage_options',
		'atualizacao',
		'page_atualizacao'
	);
	add_submenu_page(
		'edit.php?post_type=produto',
		__( 'Meus Orçamentos', 'textdomain' ),
		__( 'Meus Orçamentos', 'textdomain' ),
		'manage_options',
		'historico-orcamentos-cw',
		'requirePageOrcamentos'
	);
}
add_action('admin_menu', 'submenuProdutoAdmin');
function page_atualizacao(){
	?>
	<div class="wrap">
		<h1>Atualização</h1>
		<?php require_once( plugin_dir_path( __FILE__ ).'templates/atualizacao.php'); ?>
	</div>
	<?php
}
function requirePageConfig() { 
	?>
	<div class="wrap">
		<h1>Configurações - Orçamentos</h1>
		<?php require_once( plugin_dir_path( __FILE__ ).'templates/admin_config.php'); ?>
	</div>
	<?php
}
function requirePageOrcamentos() { 
	?>
	<div class="wrap">
		<h1>Orçamentos</h1>
		<?php require_once( plugin_dir_path( __FILE__ ).'templates/orcamentos_admin.php'); ?>
	</div>
	<?php
}

function orcamento_pagination() {
	global $wp_query;
	$big = 999999999;
	return paginate_links( array(
		'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
		'format' => '?paged=%#%',
		'current' => max( 1, get_query_var('paged') ),
		'total' => $wp_query->max_num_pages
	) );
}

function orcamento_cw_get_imgDestaque($tamanho = ''){
	$tamanho = ($tamanho) ? $tamanho : 'maximo';
	$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), $tamanho ); 
	$imgDest = ($image[0]) ? $image[0] : plugins_url( '/imagens/sem-imagem.gif', __FILE__ );
	return $imgDest;
}
function orcamento_cw_the_imgDestaque($tamanho = ''){
	$tamanho = ($tamanho) ? $tamanho : 'maximo';
	$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), $tamanho ); 
	$imgDest = ($image[0]) ? $image[0] : plugins_url( '/imagens/sem-imagem.gif', __FILE__ );
	echo $imgDest;
}

//Shor
function shortcode_produtos($array){
	$conteudo = '<div class="row">
	<div class="produtos">';

	if(get_query_var('page')){
		$page = get_query_var('page');
	}elseif (get_query_var('paged')) {
		$page = get_query_var('paged');
	}else{
		$page = 1;
	}
	$categoria = (isset($array['categoria'])) ? '"&produto_categoria='.$array['categoria'] : '';
	$posts_per_page = (isset($array['posts_per_page'])) ? '&posts_per_page='.$array['posts_per_page'] : '';
	query_posts("post_type=produto&paged=".$page.$categoria.$posts_per_page);
	$class = 'col-xs-12 col-sm-4';

	if (have_posts()) : while (have_posts()) : the_post(); 

		include( plugin_dir_path( __FILE__ ).'templates/content-produto.php');

	endwhile;
endif;

$conteudo .= '</div>
</div>
<div class="row">
<div class="col-xs-12 orcamentos_paginacao">
'.orcamento_pagination().'
</div>
</div>';
wp_reset_query();
return $conteudo;
}
add_shortcode('produtos_orcamento', 'shortcode_produtos');

function shortcode_carrossel($array){

	$caracteres = 'abcdefghijlmnopq';
	$id = substr(str_shuffle($caracteres),0,10);
	$conteudo = '
	<div class="carrossel produtos" id="'.$id.'" style="width:100%; position:relative; overflow: hidden;">
	<div class="swiper-wrapper">';

	$categoria = (isset($array['categoria'])) ? '&produto_categoria='.$array['categoria'] : '';
	query_posts("post_type=produto&showposts=500".$categoria); 
	if (have_posts()) : while (have_posts()) : the_post(); 
		$conteudo .= '<div class="swiper-slide">';				
		$style = 'style="min-height: auto;"';
		include( plugin_dir_path( __FILE__ ).'templates/content-produto.php');

		$conteudo .= '</div>';

	endwhile;
endif;
wp_reset_query();

$conteudo .= '
</div>
<div class="swiper-button-prev"><i class="fa fa-chevron-left"></i></div>
<div class="swiper-button-next"><i class="fa fa-chevron-right"></i></div>
</div>';

$conteudo .= '
<script>
jQuery(document).ready(function(){ 
	var largura = jQuery(\'#'.$id.'\').width();
	var quantSlide;
	if(largura <= 400){
		quantSlide = 1;
	}
	if(largura > 401 && largura < 600){
		quantSlide = 2;
	}
	if(largura > 601 && largura < 900){
		quantSlide = 3;
	}
	if(largura > 901 && largura < 1100){
		quantSlide = 4;
	}
	if(largura > 1100){
		quantSlide = 5;
	}

	var swiper = new Swiper(\'#'.$id.'\', {
		slidesPerView: \'auto\',
		nextButton: \'#'.$id.' .swiper-button-next\',
		prevButton: \'#'.$id.' .swiper-button-prev\',
		slidesPerView: quantSlide,
		paginationClickable: true,
		spaceBetween: 20,
		autoplay: 3000,
	});
});

</script>';

return $conteudo;
}
add_shortcode('orcamento_carrossel', 'shortcode_carrossel');

function shortcode_lsta_categorias($array){
	$titulo = (isset($array['titulo'])) ? $array['titulo'] : 'Categorias' ;
	$categoria = get_categories(array('taxonomy' => 'produto_categoria'));
	$menuCategorias = '<h2 class="widget-title"><span>'.$titulo.'</span></h2>';
	$menuCategorias .= '<ul class="nav">';
	if($categoria){		
		foreach ($categoria as $cat) {
			$menuCategorias .= '<li><a href="'.get_category_link( $cat->term_id ).'">'.$cat->name.' <span class="badge">'.$cat->count.'</span></a></li>';
		}		
	}else{
		$menuCategorias .= '<li><a href="#">Sem categoria</a></li>';
	}
	$menuCategorias .= '</ul>';
	return $menuCategorias;
}
add_shortcode('orcamento_menu_categorias', 'shortcode_lsta_categorias');

function script_orcamento_cw(){
    // Register the script like this for a plugin:
	wp_register_script( 'bootstrap', plugins_url( '/js/bootstrap.js?versao='.versao_cw(), __FILE__ ), array( 'jquery' ) );
	wp_enqueue_script( 'bootstrap' );

	wp_register_script( 'jquery.maskedinput.min', plugins_url( '/js/jquery.maskedinput.min.js?versao='.versao_cw(), __FILE__ ), array( 'jquery' ) );
	wp_enqueue_script( 'jquery.maskedinput.min' );

	wp_register_script( 'swiper.min', plugins_url( '/js/swiper.min.js?versao='.versao_cw(), __FILE__ ), array( 'jquery' ) );
	wp_enqueue_script( 'swiper.min' );

	wp_enqueue_script( 'ajax-script', plugins_url( '/js/script.js', __FILE__ ), array('jquery') );
	wp_localize_script( 'ajax-script', 'ajax_object', array( 'ajax_url' => admin_url( 'admin-ajax.php' )) );
}
add_action( 'wp_enqueue_scripts', 'script_orcamento_cw' );

function style_orcamento_cw(){
    // Register the style like this for a plugin:
	wp_register_style( 'bootstrap', plugins_url( '/css/bootstrap.css?versao='.versao_cw(), __FILE__ ));   
	wp_enqueue_style( 'bootstrap' );

	wp_register_style( 'font-awesome.min', plugins_url( '/css/font-awesome.min.css?versao='.versao_cw(), __FILE__ ));   
	wp_enqueue_style( 'font-awesome.min' );

	wp_register_style( 'animate', plugins_url( '/css/animate.css?versao='.versao_cw(), __FILE__ ));   
	wp_enqueue_style( 'animate' );

	wp_register_style( 'swiper.min', plugins_url( '/css/swiper.min.css?versao='.versao_cw(), __FILE__ ));   
	wp_enqueue_style( 'swiper.min' );

	wp_register_style( 'style-cw', plugins_url( '/css/style-cw.css?versao='.versao_cw(), __FILE__ ));   
	wp_enqueue_style( 'style-cw' );
}
add_action( 'wp_enqueue_scripts', 'style_orcamento_cw' );


function orcamento_cw_script_admin($hook) {
	if($_GET['page'] != 'configuracoes-orcamentos-cw' && $_GET['page'] != 'historico-orcamentos-cw' && $_GET['page'] != 'atualizacao'){	return;	}
	wp_enqueue_style( 'font-awesome.min', plugins_url( '/css/font-awesome.min.css?ver='.versao_cw(), __FILE__ ));
	wp_enqueue_style( 'bootstrap', plugins_url('/css/bootstrap.css?ver='.versao_cw(), __FILE__) );
	wp_enqueue_style( 'style_admin', plugins_url('/css/style_admin.css?ver='.versao_cw(), __FILE__) );
	wp_enqueue_style( 'minicolors', plugins_url('/css/minicolors.css?ver='.versao_cw(), __FILE__) );
	wp_enqueue_script( 'bootstrap', plugins_url('/js/bootstrap.js?ver='.versao_cw(), __FILE__) );
	wp_enqueue_script( 'jquery.minicolors.min', plugins_url('/js/jquery.minicolors.min.js?ver='.versao_cw(), __FILE__) );
	wp_enqueue_script( 'script_admin', plugins_url('/js/script_admin.js?ver='.versao_cw(), __FILE__) );
}
add_action( 'admin_enqueue_scripts', 'orcamento_cw_script_admin' );


/*==== Adiciona javaScript na footer da administração - INICIO =======*/
function orcamento_cw_ajax() { 
	?>
	<script>
		jQuery.ajax({
			url: 'https://cicloneweb.com.br/wp-content/themes/cicloneweb/versao-orcamento-cw.php?versao=<?php echo versao_cw()?>',
			complete: function(res){
				jQuery('body').prepend(res.responseJSON);
			}
		});
	</script>
	<?php
	if($_GET['page'] != 'configuracoes-orcamentos-cw' && $_GET['page'] != 'historico-orcamentos-cw' && $_GET['page'] != 'atualizacao'){	return;	}
	?>
	<script type="text/javascript">
		function atualiza_plugin_cw(){
			jQuery('.atualiza-plugin').html('Aguarde... <i class="fa fa-spinner fa-pulse"></i>');
			jQuery('.atualiza-plugin').attr({'disabled':'disabled'});
			jQuery('.resp-atualizacao').html('');
			var data = {
				'action': 'atualiza_plugin_cw'
			}
			jQuery.post(ajaxurl, data, function(response) {
				jQuery('.resp-atualizacao').html(response);
				jQuery('.atualiza-plugin').html('<i class="fa fa-trash"></i> Excluir'); 
			});
		}
		function excluiPedido(id){
			jQuery('#orcamento-'+id+' button.exclui').html('Aguarde... <i class="fa fa-spinner fa-pulse"></i>');
			jQuery('#orcamento-'+id+' .resp').html('');
			var data = {
				'action': 'excluiPedido',
				'id': id
			}
			jQuery.post(ajaxurl, data, function(response) {
				jQuery('#orcamento-'+id+' .resp').html(response);
				jQuery('#orcamento-'+id+' button.exclui').html('<i class="fa fa-trash"></i> Excluir'); 
			});
		}

		function modalResponde(id){
			jQuery('#responde-orcamento').modal('show');
			jQuery('#responde-orcamento .modal-body').html('<h3>Aguarde... <i class="fa fa-spinner fa-pulse"></i></h3>');
			var data = {
				'action': 'modalResponde',
				'id': id
			}
			jQuery.post(ajaxurl, data, function(response) {
				jQuery('#responde-orcamento .modal-body').html(response);
			});
		}

		function criaPagina(){
			jQuery('.criarPagina button').html('Aguarde...');

			var data = {'action': 'criarPagina'};

			jQuery.post(ajaxurl, data, function(response) {
				jQuery('.criarPagina .resp').html(response);
			});
		}

		jQuery('[data-toggle="tooltip"]').tooltip(); 

		jQuery(document).ready(function($) {
			

			jQuery('.color').minicolors();

			jQuery('#cor-tema input').click(function(){
				if(jQuery(this).is(':checked') == true){
					jQuery('#config-cores').addClass('disabled');
					jQuery('#config-cores input').attr('disabled');
				}else{
					jQuery('#config-cores').removeClass('disabled');
					jQuery('#config-cores input').removeAttr('disabled');	
				}
			});

			if(jQuery('#cor-tema input').is(':checked') == true){
				jQuery('#config-cores').addClass('disabled');
				jQuery('#config-cores input').attr('disabled');
			}else{
				jQuery('#config-cores').removeClass('disabled');
				jQuery('#config-cores input').removeAttr('disabled');	
			}

			jQuery('form.shortcode').submit(function(){  
				jQuery('form.shortcode .resp').html('');
				var categoria = jQuery('form.shortcode select').val();   
				var selectCat = (categoria != '') ? ' categoria="'+categoria+'"' : '';
				jQuery('form.shortcode .resp').html('<div><span>[orcamento_carroussel'+selectCat+']</span><br>Copie e cole onde quer que o carroussel apareça.</div>');
				return false;
			});

			jQuery('.configOrcamento').submit(function(){  
				jQuery('.configOrcamento .resp').html('');
				jQuery('.configOrcamento button[type="submit"]').html("Aguarde... <i class='fa fa-spinner fa-pulse'></i>");        

				var data = jQuery(this).serialize();

				jQuery.post(ajaxurl, data, function(response) {
					jQuery('.configOrcamento .resp').html(response);
					jQuery('.configOrcamento button[type="submit"]').html("Salvar"); 
				});
				return false;
			});

		});
	</script> 
	<?php
}
add_action( 'admin_footer', 'orcamento_cw_ajax' ); 
/*==== Adiciona javaScript na footer da administração - FIM   ========*/

function bc_get_wp_editor( $content = '', $editor_id, $options = array() ) {
	ob_start();

	wp_editor( $content, $editor_id, $options );

	$temp = ob_get_clean();
	$temp .= \_WP_Editors::enqueue_scripts();
	$temp .= \_WP_Editors::editor_js();
	//$temp .= print_footer_scripts();

	return $temp;
}


/*===== Inicio - Atualiza plugin =========== */
function atualiza_plugin_cw(){
	global $wpdb;
	$versao = array('action' => 'pluginOrcamento/verificaVersao');
	$api = api_cw($versao);
	if($api->status == 'success'){
		if($api->ultimaVersao == versao_cw() ){
			?>
			<div class="alert alert-info">
				<b>Estranho!</b> Já está com a última (<?php echo $api->ultimaVersao ?>) versão.
			</div>
			<?php
		}else{
			$arquivo = WP_PLUGIN_DIR . '/orcamento_cw_'.$api->ultimaVersao.'.zip';
			if ( copy($api->link, $arquivo) ) {
				echo "Arquivo baixado com sucesso!<br>";
				$zip = new ZipArchive;
				if($zip->open($arquivo) == TRUE ){
					$zip->extractTo( WP_PLUGIN_DIR );

					echo 'Arquivo descompactado com sucesso.<br>';

					if(  unlink($arquivo)  ){
						echo 'Arquivo .zip deletado.';
					}

					?>
					<h2>Atualizando página <i class="fa fa-spinner fa-pulse"></i></h2>
					<script>
						location.reload();
					</script>
					<?php
				}else{
					echo 'O Arquivo ('.$arquivo.') não pode ser descompactado.';
				}
				$zip->close();

			}else{
				echo "<p class='text-danger'><b>OPS!</b> Erro ao copiar a nova versao. Tente mais tarde.</p>";
			}
		}
	}else{
		echo "<p class='text-danger'><b>OPS!</b> Tente mais tarde.</p>";
	}

	wp_die();
}
add_action( 'wp_ajax_atualiza_plugin_cw', 'atualiza_plugin_cw' );
/*===== Fim - Atualiza plugin =========== */

/*===== Funcão que recebe o action "criarPagina" - INICIO ========*/
function criarPagina() {
	global $wpdb; // this is how you get access to the database

	$erro = true;

	query_posts('post_type=page&name=orcamentos');
	if (!have_posts()){
		$my_post = array(
			'post_title'    => wp_strip_all_tags('Orçamentos'),
			'post_status'   => 'publish',
			'post_type'   	=> 'page'
		);
		$pageId = wp_insert_post( $my_post );
		if($pageId){
			update_post_meta( $pageId, '_wp_page_template', 'finaliza_orcamento.php' );
			$erro = false;
		}
	}

	query_posts('post_type=page&name=produtos');
	if (!have_posts()){
		$my_post = array(
			'post_title'    => wp_strip_all_tags('Produtos'),
			'post_content'  => '[produtos_orcamento]',
			'post_status'   => 'publish',
			'post_type'   	=> 'page'
		);
		$pageId = wp_insert_post( $my_post );
		if($pageId){
			$erro = false;
		}
	}

	if($erro == false){
		?>
		<script>
			jQuery('.criarPagina').html('<div class="alert alert-success"><b>OK</b> Páginas criadas com sucesso</div>');
		</script>

		<?php
	}

	wp_die(); // this is required to terminate immediately and return a proper response
}	
add_action( 'wp_ajax_criarPagina', 'criarPagina' );
/*===== Funcão que recebe o action "criarPagina" - FIM     =======*/


/*===== Exclui pedido de orcamento ======*/
function excluiPedido(){
	global $wpdb;
	$id = $_POST['id'];
	$wpdb->get_results("DELETE FROM orcamentos_cw_pedidos WHERE id = '$id'");
	$confirma = $wpdb->get_results("SELECT * FROM orcamentos_cw_pedidos WHERE id = '$id'");
	if(!$confirma){
		?>
		<script>jQuery('#orcamento-<?php echo $id;?>').hide('slow');</script>
		<?php
	}else{
		?>
		<div class="alert alert-danger"><b>Erro!</b> Tente mais tarde.</div>
		<?php
	}
	wp_die();
}
add_action( 'wp_ajax_excluiPedido', 'excluiPedido' );
/*===== FIM - Exclui pedido de orcamento ======*/

/*===== Abre modal pra responder ao orcamento ======*/
function modalResponde(){
	global $wpdb;
	$config = unserialize(get_option('configOrcamento'));
	$id = $_POST['id'];
	$orcamento = $wpdb->get_results("SELECT * FROM orcamentos_cw_pedidos WHERE id = '$id'");
	if($orcamento[0]){
		$orcamento = $orcamento[0];
		$mensagemPadrao = "<h3>Olá <b>[cw_nomeCliente]</b></h3>
		<p><b>Seu orçamento:</b></p>
		[cw_listaProdutos]
		<br>
		<h4>Resposta ao orçamento:</h4>
		(<span style='color:red'>escreva aqui a resposta</span>)
		<hr>
		<p><b>Atenciosamente</b></p>
		<p>[cw_nomeSite]</p>
		<p>[cw_siteUrl]</p>";
		
		$mensagem = ($config['resposta_orcamento'] != '') ? $config['resposta_orcamento'] : $mensagemPadrao;
		$mensagem = str_replace("[cw_nomeCliente]", $orcamento->nomeCliente, $mensagem);
		$mensagem = str_replace("[cw_listaProdutos]", $orcamento->produtos, $mensagem);
		$mensagem = str_replace("[cw_nomeSite]", get_option('blogname'), $mensagem);
		$mensagem = str_replace("[cw_siteUrl]", '<a href="'.get_option('siteUrl').'">'.get_option('siteUrl').'</a>', $mensagem);
		$mensagem = "<div style='background-color: #ccc; padding-top: 15px; padding-bottom:15px; width:100%'>
		<div style='width: 500px; background-color: #fff; margin: auto; padding: 15px'>
		$mensagem
		</div>
		</div>"; 
		$args = array('tinymce'  => array('toolbar1'      => ''),'quicktags' => false,	'textarea_rows' => 15,	'media_buttons' => false);
		?>

		<form class="resposta_orcamento">
			<input type="hidden" name="id" value="<?php echo $orcamento->id ?>">
			<input type="hidden" name="action" value="resposta_orcamento">
			<div class="form-group">
				<input class="form-control" type="email" name="emailCliente" value="<?php echo $orcamento->emailCliente ?>">
			</div>
			<div class="form-group">
				<?php echo bc_get_wp_editor(nl2br($mensagem), 'resposta_orcamento', $args);?>
				<br>
				<div class="resp"></div>
				<div class="form-group text-right">
					<button class="btn btn-lg btn-primary" type="submit">Responder</button>
				</div>
			</div>

		</form>
		<script>
			jQuery('.resposta_orcamento').submit(function(){
				jQuery('.resposta_orcamento button[type="submit"]').html("Aguarde... <i class='fa fa-pulse'></i>"); 
				jQuery('.resposta_orcamento button[type="submit"]').attr('disabled','disabled');
				var data = jQuery(this).serialize();

				jQuery.post(ajaxurl, data, function(response) {
					jQuery('.resposta_orcamento .resp').html(response);
					jQuery('.resposta_orcamento button[type="submit"]').removeAttr('disabled');
					jQuery('.resposta_orcamento button[type="submit"]').html("Responder"); 
				});
				return false;
			});
		</script>
		<?php		
	}else{
		echo '<div class="alert alert-danger"><b>Erro!</b> Tente mais tarde</div>';
	}
	wp_die();
}
add_action( 'wp_ajax_modalResponde', 'modalResponde' );
/*===== FIM - Abre modal pra responder ao orcamento ===== */

add_action( 'wp_ajax_resposta_orcamento', 'resposta_orcamento' );
function resposta_orcamento(){
	global $wpdb;
	$idorcamento  = $_POST['id'];
	$emailCliente = $_POST['emailCliente'];
	$body         = $_POST['resposta_orcamento'];
	$headers = array('Content-Type: text/html; charset=UTF-8','From: '.get_option('blogname').' <'.get_option('admin_email').'>');
	$enviaEmail = wp_mail( $emailCliente, 'Resposta ao seu orçamento', $body, $headers);
	if($enviaEmail){
		$wpdb->get_results("INSERT INTO orcamentos_cw_resposta (id_orcamento, resposta, data) VALUES ('$idorcamento', '$body', now())");
		?>
		<div class="alert alert-success"><b>Sucesso!</b> Sua mensagem foi enviada.</div>
		<?php
	}else{
		?>
		<div class="alert alert-danger"><b>Erro!</b> Sua mensagem não foi enviada..<?php echo $enviaEmail ?></div>
		<?php
	}
	wp_die();
}


/*===== Funcão que recebe o action "configOrcamento" - INICIO ========*/
/*Preeche tabela com as informações de estilo e campos na finalização*/
function configOrcamento() {	
	global $wpdb;

	if ( get_option( 'configOrcamento' ) !== false ) {
		update_option( 'configOrcamento', serialize($_POST) );
	}else{
		add_option( 'configOrcamento', serialize($_POST), null, 'no' );
	}

	echo '<div class="alert alert-success">OK</div>';
	wp_die();
}
add_action( 'wp_ajax_configOrcamento', 'configOrcamento' );
/*===== Funcão que recebe o action "configOrcamento" - FIM    ========*/


/*===== Funcão que recebe o action "clicou_orcamento" - INICIO ========*/
function clicou_orcamento(){
	$id 	= $_POST['id'];
	$quant 	= (isset($_POST['quant'])) ? $_POST['quant'] : 1;
	$origem	= $_POST['origem'];
	$exclui	= (isset($_POST['exclui'])) ? $_POST['exclui'] : '';
	$id_unico = $id;

	global $wpdb;

	if($quant == 0){
		$quant = 1;
	}
	$car = $_COOKIE['carrinho'];
	$array = unserialize($car);

	if($exclui == ''){
		if($origem == '2'){	
			// 2 = carrinho		
			$array[$id] = (int)$quant;
			if(setcookie('carrinho', serialize($array), (time() + (30 * 24 * 3600)), '/')){
			}
		}
		if($origem == 'page-produto'){		
			if($array[$id] == null){
				$array[$id] = (int)$quant;
				if(setcookie('carrinho', serialize($array), (time() + (30 * 24 * 3600)), '/')){

					$carrinho = array_keys($array);

					for($i = 0; $i < count($carrinho); $i++){
						query_posts("post_type=produto&p=".$carrinho[$i]);
						if (have_posts()) : while (have_posts()) : the_post();
							global $post;
							$pisca = ($post->ID == $id_unico) ? ' pisca' : '';
							$id_produto_atual = $post->ID;
							$image = orcamento_cw_get_imgDestaque('thumbnail');
							$titulo = get_the_title();

							$produtoCarrinho .="<div class='row$pisca' id='".$post->ID."'><div class='col-xs-2 hidden-xs'><img src='".$image."'></div><div class='col-xs-9 col-sm-6'><h4>".$titulo."</h4></div><div class='col-xs-2 hidden-xs'><input type='number' id='quant$carrinho[$i]' class='form-control' style='margin-top:8px;' onkeyup=\'alteraQuant(".$post->ID.", this);\' onclick=\'alteraQuant(".$post->ID.", this);\' onblur=\'orcamento($carrinho[$i], 2);\' name='quant' value='".$array[$carrinho[$i]]."'></div><div class='col-xs-3 col-sm-2'><button class='excluiModal' onclick='excluiModal(".$post->ID.");'><span class='fa fa-trash'></span></button></div><div class='col-xs-12'><hr style='margin-bottom: 5px; margin-top: 5px;'></div></div>";
						endwhile;
					endif;
				}

				echo '<script>jQuery("#resposta_orcamento").modal("show");</script>';
				echo '<script>jQuery(".btn-produto").html("<b>PRODUTO ADICIONADO</b>");</script>';
				echo '<script>jQuery("#conteudo-orcamento").html("'.$produtoCarrinho.'"); pisca();</script>';
			}
		}else{
			$array[$id] = (int)$quant;
			if(setcookie('carrinho', serialize($array), (time() + (30 * 24 * 3600)), '/')){

				$carrinho = array_keys($array);

				for($i = 0; $i < count($carrinho); $i++){
					query_posts("post_type=produto&p=".$carrinho[$i]);
					if (have_posts()) : while (have_posts()) : the_post();
						global $post;
						$pisca = ($post->ID == $id_unico) ? ' pisca' : '';
						$image = orcamento_cw_get_imgDestaque('thumbnail');
						$titulo = get_the_title();
						$produtoCarrinho .="<div class='row$pisca' id='".$post->ID."'><div class='col-xs-2 hidden-xs'><img src='".$image."'></div><div class='col-xs-9 col-sm-6'><h4>".$titulo."</h4></div><div class='col-xs-2 hidden-xs'><input type='number' id='quant$carrinho[$i]' class='form-control' style='margin-top:8px;' onkeyup=\'alteraQuant(".$post->ID.", this);\' onclick=\'alteraQuant(".$post->ID.", this);\' onblur=\'orcamento($carrinho[$i], 2);\' name='quant' value='".$array[$carrinho[$i]]."'></div><div class='col-xs-3 col-sm-2'><button class='excluiModal' onclick='excluiModal(".$post->ID.");'><span class='fa fa-trash'></span></button></div><div class='col-xs-12'><hr style='margin-bottom: 5px; margin-top: 5px;'></div></div>";
					endwhile;
				endif;
			}

			echo '<script>jQuery("#resposta_orcamento").modal("show");</script>';
			echo '<script>jQuery(".btn-produto").html("<b>PRODUTO ADICIONADO</b>");</script>';
			echo '<script>jQuery("#conteudo-orcamento").html("'.$produtoCarrinho.'"); pisca();</script>';
		}
	}
}
}else{
	unset($array[$id]);
	if(setcookie('carrinho', serialize($array), (time() + (30 * 24 * 3600)), '/')){
		echo '<script>jQuery("#'.$id.'").hide("500");</script>';
	}
}
$quantCar = count($array);
if($quantCar == 0){
	?>
	<script>jQuery("#carrinho_orcamento").html("<div class='col-md-12 col-xs-12 col-sm-12 text-center'><h2>Sua lista de orçamento está vazia</h2><a href='/' class='btn btn-primary'>Pagina Inicial</a></div>");
	jQuery("html, body").animate({
		scrollTop: jQuery("section .container").offset().top
	}, 800);
</script>
<?php
}
echo '<script>jQuery("#itens").html("'.$quantCar.'");</script>';

wp_die();
}
add_action('wp_ajax_clicou_orcamento', 'clicou_orcamento');
add_action('wp_ajax_nopriv_clicou_orcamento', 'clicou_orcamento');
/*===== Funcão que recebe o action "clicou_orcamento" - FIM    ========*/


/*===== Funcão que recebe o action "finaliza_orcamento" - INICIO    ========*/
function finaliza_orcamento(){
	global $wpdb;

	if (!function_exists('wp_handle_upload')) {
		require_once(ABSPATH . 'wp-admin/includes/file.php');
	}

	$car= isset($_COOKIE["carrinho"]) ? $_COOKIE["carrinho"] : "";
	$array = unserialize(stripslashes($car)); 
	if(is_array($array)){
		$dd = array_keys($array);
		if($dd != null){
			$orcamento = '<table class="table" style="width: 100%; max-width: 500px; text-align: center; border: 1px solid;">
			<thead>
			<tr>
			<th>ID</th>
			<th style="text-align: left">Produto</th>
			<th>Quantidade</th>
			</tr>
			</thead>
			<tbody>'; 
			for($i = 0; $i < count($dd); $i++){
				query_posts("post_type=produto&p=".$dd[$i]);
				if (have_posts()) :
					
					while (have_posts()) : the_post(); 
						global $post;
						$produto = get_the_title();
						$quantidade = $array[$dd[$i]];
						$orcamento .= '<tr>
						<td>'.$post->ID.'</td>
						<td style="text-align: left"><a href="'.get_the_permalink().'" target="_blank">'.$produto.'</a></td>
						<td>'.$quantidade.'</td>
						</tr>';
					endwhile;
					
				endif;				
				wp_reset_postdata();
			}
			$orcamento .= '</tbody></table>';
		}
	}else{
		setcookie('carrinho', '', (time() + (30 * 24 * 3600)), '/');
		echo "<div class='alert alert-danger' role='alert'>Erro ao enviar. Tente mais tarde.</div>";
		exit;
	}

	foreach ($_POST as $key => $value) {
		$dadosCliente .= ($key != 'action' && $key != 'file') ? '<b>'.$key.':</b> '.$value.'<br>' : '';		
	}

	$email = $_POST['email'];
	$nome = $_POST['nome'];

	if($email != ''){
		$attachments = '';
		if(isset($_FILES['file'])){
			$uploadedfile = $_FILES['file'];
			$upload_overrides = array('test_form' => false);
			$movefile = wp_handle_upload($uploadedfile, $upload_overrides);

			$arquivo = ($movefile['url']) ? '<b>Anexo:</b> <a target="_blanc" href="'.$movefile['url'].'">'.$movefile['url'].'</a>' : '';
			if ($movefile && !isset($movefile['error'])) {
				$attachments = array($movefile['file']);
			}
		}

		$to = get_option('admin_email');
		$subject = 'Novo orçamento - '.get_option('blogname');
		$body = '
		<h2>Parabéns, você acaba de receber mais outro Orçamento</h2>
		<h3>Dados do solicitante</h3>
		'.$dadosCliente.'
		<h3>Dados do orçamento</h3>
		'.$orcamento.'
		'.$arquivo;

		$headers = array('Content-Type: text/html; charset=UTF-8');

		$novo = $wpdb->get_results("INSERT INTO orcamentos_cw_pedidos (nomeCliente, emailCliente, orcamento, data, produtos) VALUES ('$nome', '$email', '$body', now(), '$orcamento')");

		$id_gerado = $wpdb->insert_id;
		if($id_gerado != 0){
			setcookie('carrinho', '', (time() + (30 * 24 * 3600)), '/');
			if(wp_mail( $to, $subject, $body, $headers, $attachments )){

				echo "<script>jQuery('#carrinho_orcamento').html('<div class=\'col-md-12 col-sm-12 col-lg-12 text-center\'><h1>Obrigado, $nome!</h1> <h2>Seu orçamento foi recebido. Em breve lhe responderemos.</h2></div>');
				jQuery('html, body').animate({
					scrollTop: jQuery('section .container').offset().top
				}, 800);
				jQuery('#itens').html('0');</script>";

			}else{
				echo "<script>jQuery('#carrinho_orcamento').html('<div class=\'col-md-12 col-sm-12 col-lg-12 text-center\'><h1>Obrigado, $nome!</h1> <h2>Seu orçamento foi recebido. Em breve lhe responderemos.</h2><br><i class=\'text-danger\'>O email não foi enviado, mas o orçamento foi cadastrado com sucesso.</i></div>');
				jQuery('html, body').animate({
					scrollTop: jQuery('section .container').offset().top
				}, 800);
				jQuery('#itens').html('0');</script>";
			}

		}else{
			echo "<div class='alert alert-danger' role='alert'>Erro ao enviar. Tente mais tarde. ".$wpdb->last_error."</div>";
		}



	}else{
		echo "<div class='alert alert-danger' role='alert'>Sem email.</div>";
	}

	wp_die();

}
add_action('wp_ajax_finaliza_orcamento', 'finaliza_orcamento');
add_action('wp_ajax_nopriv_finaliza_orcamento', 'finaliza_orcamento');
/*===== Funcão que recebe o action "finaliza_orcamento" - FIM    ========*/



function registra_produto() {
	$labels = array(
		"name" => __( "Produtos" ),
		"singular_name" => __( "Produto" ),
		"menu_name" => __( "Meus produtos" ),
		"all_items" => __( "Todos produtos" ),
		"add_new" => __( "Adicionar produto" ),
		"add_new_item" => __( "Novo produto" ),
		"edit_item" => __( "Editar produto" ),
		"new_item" => __( "Novo produto" ),
		"view_item" => __( "Ver produto" ),
		"view_items" => __( "Ver produtos" ),
		"search_items" => __( "Procurar produto" ),
	);

	$args = array(
		'labels'             => $labels,
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'produto' ),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => null,
		"menu_icon" 		 => "dashicons-megaphone",
		'supports'           => array( 'title', 'editor', 'thumbnail' ),
	);

	// Registra o custom post
	register_post_type( 'produto', $args );

	// Registra a categoria personalizada
	register_taxonomy( 
		'produto_categoria', 
		array( 
			'produto' 
		), 
		array(
			'hierarchical' => true,
			'label' => __( 'Categoria' ),
			'show_ui' => true,
			'show_in_tag_cloud' => true,
			'query_var' => true,
			'rewrite' => array('slug' => 'produto_categoria'),
		)
	);
}
add_action( 'init', 'registra_produto' );

function template_single_produto($template) {
	global $post;
	if ($post->post_type == "produto"){
		$plugin_path = plugin_dir_path( __FILE__ );
		$template_name = 'templates/single-produto.php';
		if($template === get_stylesheet_directory() . '/' . $template_name	|| !file_exists($plugin_path . $template_name)) {
			return $template;
		}
		return $plugin_path . $template_name;
	}
	return $template;
}
add_filter('single_template', 'template_single_produto');

require_once(plugin_dir_path( __FILE__ ). 'templates/pagetemplater.php');

function override_tax_template($template){
	if ( is_tax($taxonomy_single) ) {
		$template = plugin_dir_path( __FILE__ ) . 'templates/taxonomy-produto_categoria.php';
	}
	return $template;
}
add_filter('template_include','override_tax_template');

function modalfooter() {
	?>
	<div id="retorno"></div>
	<div class="modal fade" id="resposta_orcamento">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<span class="modal-title" id="myModalLabel"><h3>Meus orçamentos</h3></span>
				</div>
				<div class="modal-body" id="conteudo-orcamento">

				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default pull-left" data-dismiss="modal"><span class="hidden-xs">Continuar na página</span><span class="hidden-md hidden-lg hidden-sm"><b>X</b></span></button>
					<?php 
					$config = get_option('configOrcamento');
					$orcamento_text = (orcamentoConfig('finalizacao_texto')) ? orcamentoConfig('finalizacao_texto') : 'Enviar Orçamento';
					$orcamento_back_color = orcamentoConfig('finalizacao_cor_fundo');
					$orcamento_text_color = orcamentoConfig('finalizacao_cor_texto');
					?>
					<a href="<?php echo get_option('siteUrl') ?>/orcamento" class="acessaOrcamento btn <?php echo orcamentoConfig('finalizacao_class') ?>" style="background-color: <?php echo $orcamento_back_color ?>; color: <?php echo $orcamento_text_color ?>"><b>IR PARA FINALIZAÇÃO</b></a>
				</div>
			</div>
		</div>
	</div>

	<?php
}
add_action( 'wp_footer', 'modalfooter' );

require_once(ABSPATH . '/wp-admin/includes/plugin.php');

// Verifica se o plugin está ativado...
if (!is_plugin_active('advanced-custom-fields/acf.php')) {
	/* Este código chama os arquivos que exigem a instalação dos plugins necessários para o tema.*/
	require_once( plugin_dir_path( __FILE__ ) . 'tgm/class-tgm-plugin-activation.php' );
	require_once( plugin_dir_path( __FILE__ ) . 'tgm/plugins-list.php' );
}else{
	/***  Galeria ACF  ***/
	add_action('acf/register_fields', 'acfgp_register_fields');

	function acfgp_register_fields(){
		include_once('galeria/galeria.php');
	}

	/***  Galeria ACF  ***/
	if(function_exists("register_field_group")){
		register_field_group(array (
			'id' => 'acf_produtos',
			'title' => 'Produtos',
			'fields' => array (
				array (
					'key' => 'field_59dfa21edd743',
					'label' => 'Galeria',
					'name' => 'galeria',
					'type' => 'gallery',
					'preview_size' => 'thumbnail',
					'library' => 'all',
				),
				array (
					'key' => 'field_5a58aa863300e',
					'label' => 'Resumo',
					'name' => 'resumo',
					'type' => 'textarea',
					'instructions' => 'Esse breve resumo aparecerá na página do produto, ao lado da imagem.',
					'default_value' => '',
					'placeholder' => '',
					'maxlength' => '',
					'rows' => '',
					'formatting' => 'br',
				),

				array (
					'key' => 'field_5a58015eed769',
					'label' => 'Relacionados',
					'name' => 'relacionados',
					'type' => 'relationship',
					'return_format' => 'object',
					'post_type' => array (
						0 => 'produto',
					),
					'taxonomy' => array (
						0 => 'all',
					),
					'result_elements' => array (
						0 => 'featured_image',
						1 => 'post_title',
					),
					'max' => '',
				),
			),
			'location' => array (
				array (
					array (
						'param' => 'post_type',
						'operator' => '==',
						'value' => 'produto',
						'order_no' => 0,
						'group_no' => 0,
					),
				),
			),
			'options' => array (
				'position' => 'normal',
				'layout' => 'default',
				'hide_on_screen' => array (
				),
			),
			'menu_order' => 0,
		));
	}
}

/* ADD BOTAO EDITOR DE TEXTO*/
add_action( 'admin_init', 'my_tinymce_button' );

function my_tinymce_button() {
	if ( current_user_can( 'edit_posts' ) && current_user_can( 'edit_pages' ) ) {
		add_filter( 'mce_buttons', 'my_register_tinymce_button' );
		add_filter( 'mce_external_plugins', 'my_add_tinymce_button' );
	}
}

function my_register_tinymce_button( $buttons ) {
	array_push( $buttons, "button_eek", "button_green" );
	return $buttons;
}

function my_add_tinymce_button( $plugin_array ) {
	$plugin_array['my_button_script'] = plugins_url( '/js/botao-editor.js', __FILE__ ) ;
	return $plugin_array;
}

foreach ( array('post.php','post-new.php') as $hook ) {
	add_action( "admin_head", 'modal_botao_editor' );
}
function modal_botao_editor() {
	?>
	<div class="modal-cw" style="display: none;">
		<div class="fecha-modal-cw fundo"></div>
		<div class="modal-content">
			<div class="title">
				<button type="button" class="fecha-modal-cw media-modal-close">
					<span class="media-modal-icon">
						<span class="screen-reader-text">Fechar o painel de mídia</span>
					</span>
				</button>
				<h3>Orçamentos CW - O que deseja inserir?</h3>
			</div>
			<div class="content">
				<p>Selecione um item dabaixo e siga os passos seguintes.</p>
				<div class="sanfona-cw">
					<div class="item">
						<div class="titulo">
							<span class="dashicons dashicons-arrow-down-alt2"></span>
							<h4>Carrossel de produtos</h4>
						</div>
						<div class="conteudo">
							<p>Um carroucel será exibido na página. Selecione uma categoria:</p>
							<select class="carroucel-cw">
								<option value="">Todos os produtos</option>
								<?php 
								$args=array('taxonomy' => 'produto_categoria', 'post_type' => 'produto', 'orderby'=> 'title', 'order' => 'ASC');
								$categories=get_categories($args);

								foreach($categories as $category) { 
									?>
									<option value="<?php echo $category->slug; ?>"><?php echo $category->name; ?></option>
									<?php 
								}
								?>
							</select>
							<button type="button" class="button button-primary button-large" onclick="add_shortcode('carrossel');">Adicionar Carroucel</button>
						</div>
					</div>

					<div class="item">
						<div class="titulo">
							<span class="dashicons dashicons-arrow-down-alt2"></span>
							<h4>Página de produtos</h4>
						</div>
						<div class="conteudo">
							<p>Mostrar todos os seus produtos.</p>

							<select class="produtos-categorias-cw" multiple>
								<option value="">Todos os produtos</option>
								<?php 
								$args=array('taxonomy' => 'produto_categoria', 'post_type' => 'produto', 'orderby'=> 'title', 'order' => 'ASC');
								$categories=get_categories($args);

								foreach($categories as $category) { 
									?>
									<option value="<?php echo $category->slug; ?>"><?php echo $category->name; ?></option>
									<?php 
								}
								?>
							</select>
							<p>Quantidade por página</p>
							<input type="number" value="10" name="posts_per_page">

							<button type="button" class="button button-primary button-large" onclick="add_shortcode('produtos');">Adicionar Produtos</button>


						</div>
					</div>

					<div class="item">
						<div class="titulo">
							<span class="dashicons dashicons-arrow-down-alt2"></span>
							<h4>Menu de Categorias</h4>
						</div>
						<div class="conteudo">
							<p>Insira lista (menu) com a categorias. Título padrão "Categorias", pode ser alterado.</p>
							<label for="cat-titulo">
								<b>Titulo:</b> <br>
								<input type="text" id="cat-titulo" value="Categorias">
							</label>
							<button type="button" class="button button-primary button-large" onclick="add_shortcode('menuCategorias');">Adicionar Categorias</button>
						</div>
					</div>
				</div>
				<hr>
				<p>Dúvidas? Acesse a <a href="https://cicloneweb.com.br" target="_blanc">página oficial</a>.</p>
			</div>
		</div>
	</div>
	<script>
		function copiarShortcode(id){
			var copyText = jQuery(id);;
			copyText.select();
			document.execCommand("copy");
		}
		function urlPlugin(){
			return '<?php echo plugins_url( '', __FILE__ ) ?>';
		}
		jQuery('.fecha-modal-cw').click(function(){
			jQuery('.conteudo').slideUp();
			var modal = jQuery(this).parents('.modal-cw').toggle();
		});


		function add_shortcode(tipo){
			switch(tipo){

				/********** CARROSSEL *********/
				case 'carrossel':
				var categoria = jQuery('select.carroucel-cw').val();
				if(categoria != ''){
					categoria = ' categoria="'+categoria+'"';
				}else{
					categoria = '';
				}
				var shortcode = '[orcamento_carrossel'+categoria+']';
				break;

				/********** PRODUTOS **********/
				case 'produtos':
				var categoria = jQuery('select.produtos-categorias-cw').val();
				var posts_per_page = jQuery('input[name="posts_per_page"]').val();
				if(posts_per_page != null){
					posts_per_page = ' posts_per_page="'+posts_per_page+'"';
				}else{
					posts_per_page = '';
				}
				if(categoria != null){
					categoria = ' categoria="'+categoria+'"';
				}else{
					categoria = '';
				}
				var shortcode = '[produtos_orcamento'+categoria+posts_per_page+']';
				break;

				/******* MENU de CATEGORIAS *******/
				case 'menuCategorias':
				var titulo = jQuery('#cat-titulo').val();
				var shortcode = '[orcamento_menu_categorias titulo="'+titulo+'"]';
				break;

				default:
				alert('Ops.. Não encontramos a função "'+tipo+'"');
				return false;
			}


			var editor = tinymce.get('content');
			editor.selection.setContent(shortcode);
			jQuery('.modal-cw').toggle();
			return false;
		}

		jQuery('.item .titulo').click(function(){
			jQuery(this).siblings('.conteudo').slideToggle( "slow" );
		});
	</script>
	<style>
	.modal-cw {
		position: fixed;
		z-index: 10000;
		background-color: #00000061;
		height: 100%;
		width: 100%;
	}
	.modal-cw>.fundo{
		width: 100%;
		height: 100%;
		position: absolute;
	}
	.modal-cw .modal-content {
		max-width: 750px;
		max-height: 80%;
		width: 100%;
		background-color: #fff;
		margin: auto;
		margin-top: 40px;
		padding-top: 0;
		z-index: 1000;
		position: relative;
		overflow: auto;
	}
	.modal-cw .title {
		background-color: #f1f1f1;
		padding: 1px 1px 1px 15px;
		position: relative;
	}
	.modal-cw .content{
		padding: 15px;
	}

	/*SANFONA*/
	.sanfona-cw .item {
		border: 1px solid #efefef;
		border-radius: 5px;
		margin-bottom: 10px;
	}
	.sanfona-cw>.item>.titulo {
		background-color: #f7f7f7;
		position: relative;
		padding: 5px;
		padding-left: 15px;
	}
	.sanfona-cw>.item>.titulo>span{
		float: right;
		margin-right: 10px;
		margin-top: 5px;
	}
	.sanfona-cw>.item>.titulo>h4{
		margin-top: 7px;
		margin-bottom: 7px;
	}
	.sanfona-cw>.item>.conteudo{
		padding: 15px;
		display: none;
	}
</style>
<?php
}
?>