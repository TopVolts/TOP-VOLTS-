function alteraQuant(id, i){
  var quant = jQuery(i).val();
  jQuery('#quant'+id).val(quant);
  orcamento(id, 2);
}
function orcamento(id, origem, exclui){
  jQuery('.acessaOrcamento').attr({disabled:''});
  var botao = jQuery('.produto-'+id).html();
  jQuery('.produto-'+id).html('<b>Aguarde... <span class="fa fa-cog fa-spin"></span></b>');
  var quant = jQuery('#quant' + id).val();
  if(exclui == 'exclui'){
    jQuery('#exclui' + id).html('<span class="fa fa-cog fa-spin"></span>');
    jQuery('#' + id + ' button').html('<span class="fa fa-cog fa-spin"></span>');
  }

  var data = {
    'action': 'clicou_orcamento',
    'id': id,
    'quant': quant,
    'origem': origem,
    'exclui': exclui
  }

  jQuery.post(ajax_object.ajax_url, data, function(response) {
    jQuery('.acessaOrcamento').removeAttr('disabled');
    jQuery('#retorno').html(response);
    jQuery('.produto-'+id).html(botao);
  });

}

function pisca(){
  jQuery('.pisca').animate({opacity: '0.1'},400);
  jQuery('.pisca').animate({opacity: '1'},350);
  jQuery('.pisca').animate({opacity: '0.1'},200);
  jQuery('.pisca').animate({opacity: '1'},100);
  jQuery('.pisca').animate({opacity: '0.1'},50);
  jQuery('.pisca').animate({opacity: '1'},50);
  jQuery('.pisca').animate({opacity: '0.1'},50);
  jQuery('.pisca').animate({opacity: '1'},50);
}


function excluiModal(id){
  jQuery('#' + id + ' button').html('<span class="fa fa-cog fa-spin"></span>');
  var data = {
    'action': 'clicou_orcamento',
    'id': id,
    'exclui': 'exclui'
  }

  jQuery.post(ajax_object.ajax_url, data, function(response) {
    jQuery('#retorno').html(response);
  });    
}


jQuery(document).ready(function($){
  $('#cw-cep').mask("99999-999");
  $('input[name="rg"]').mask("99.999.999-9");
  $('input[name="cpf"]').mask("999.999.999-99");
  $('input[name="cnpj"]').mask("99.999.999/9999-99");

  var galleryTop = new Swiper('.gallery-top', {
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
    spaceBetween: 10,
    loopedSlides: 5,
  });
  var galleryThumbs = new Swiper('.gallery-thumbs', {
    spaceBetween: 2,
    slidesPerView: 6,
    touchRatio: 0.2,
    loopedSlides: 5,
    slideToClickedSlide: true,
    centeredSlides: true,
  });
  galleryTop.params.control = galleryThumbs;
  galleryThumbs.params.control = galleryTop;
  
  jQuery('.form-orcamento').submit(function(){        
    jQuery('.form-orcamento button').attr({disabled:''});
    jQuery('.form-orcamento .enviar button').html('<b>Aguarde... <span class="fa fa-cog fa-spin"></span></b>');
    if(jQuery('.form-orcamento input[name="arquivo"').length){
     //var data = jQuery( this ).serialize(); 
     var form_data = new FormData(this);

     var arquivo = jQuery('.form-orcamento input[name="arquivo"').val();
     if(arquivo != ''){
      var arquivo = jQuery('.form-orcamento input[name="arquivo"').prop('files')[0];
    }
    form_data.append('file', arquivo);
    jQuery.ajax({
      url: ajax_object.ajax_url,
      type: 'post',
      contentType: false,
      processData: false,
      data: form_data,
      success: function (data) {
        jQuery('.form-orcamento .enviar button').html('<b>FINALIZAR</b>');
        jQuery('.form-orcamento .enviar #resp-orcamento').html(data);
        jQuery('.form-orcamento button').removeAttr('disabled');
      }
    });
  }else{
    var form_data = jQuery( this ).serialize(); 
    jQuery.ajax({
      url: ajax_object.ajax_url,
      type: 'post',
      data: form_data,
      success: function (data) {
        jQuery('.form-orcamento .enviar button').html('<b>FINALIZAR</b>');
        jQuery('.form-orcamento .enviar #resp-orcamento').html(data);
        jQuery('.form-orcamento button').removeAttr('disabled');
      }
    });
  }
  
  return false;
});  
  

  jQuery('#cw-cep').blur(function(){
    var cep = jQuery('#cw-cep').val();
    jQuery.ajax({
      url: 'http://cep.republicavirtual.com.br/web_cep.php?formato=json&cep='+cep,
      complete: function(res){
        var data = res.responseJSON;
        console.log(data);
        if(data.resultado == 1){
          jQuery('#cw-rua').val(data.logradouro);
          jQuery('#cw-bairro').val(data.bairro);
          jQuery('#cw-cidade').val(data.cidade);
          jQuery('#cw-estado').val(data.uf); 
          jQuery('#cw-numero').focus();
          jQuery('#cw-load_cep').html("");
        }else{
          jQuery('#cw-load_cep').html("<span style='color:red'>CEP Invalido</span>");
        }
      }
    });    
  });

});


