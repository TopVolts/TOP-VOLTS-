<?php

get_header(); ?>
<section class="carrinho module">
	<div class="container wrap">
		<div class="row">

			<?php
			$car= isset($_COOKIE["carrinho"]) ? $_COOKIE["carrinho"] : "";
			$array = unserialize(stripslashes($car));
			if(is_array($array)){
				$dd = array_keys($array);
				if($dd != null){
					?>
					<div id="carrinho_orcamento" class="col-xs-12 col-md-offset-1 col-md-10">
						<div class="row">
							<div class="col-xs-12 text-center">
								<h1>Meus Orçamentos</h1>
							</div>

							<div class="col-md-5 col-sm-5 col-lg-5 hidden-xs">
								<h3>Produto</h3>
							</div>
							<div class="col-md-7 col-sm-7 col-lg-7 hidden-xs">
								<h3>Quantidade</h3>
							</div>
						</div>
						<?php
						for($i = 0; $i < count($dd); $i++){
							query_posts("post_type=produto&p=".$dd[$i]);
							if (have_posts()) : while (have_posts()) : the_post(); ?>

							<div class="col-xs-12 produto-car" id="<?php echo $dd[$i];?>">

								<div class="row">
									<div class="col-sm-1 col-xs-3">
										<div class="row">
											<a href="<?php the_permalink();?>">				
												<img src="<?php orcamento_cw_the_imgDestaque('thumbnail'); ?>" alt="<?php the_title(); ?>" title="<?php the_title(); ?>" width="100%">
											</a>
										</div>
									</div>
									<div class="col-xs-9 col-sm-11">
										<div class="row">

											<div class="col-xs-9">
												<div class="row">
													<div class="col-sm-6 col-xs-12 xx">						
														<a href="<?php the_permalink();?>"><h4>	<?php the_title();?></h4></a>
													</div>
													<div class="col-sm-6 form-horizontal">

														<div class="row">							
															<div class="col-sm-6 col-xs-12">
																<input type="number" class="quantidade form-control" id="quant<?php echo $dd[$i];?>" onkeyup="orcamento('<?php echo $dd[$i];?>', '2');" onclick="orcamento('<?php echo $dd[$i];?>', '2');" onblur="orcamento('<?php echo $dd[$i];?>', '2');" value="<?php echo $array[$dd[$i]];?>">
															</div>
														</div>

													</div>
												</div>
											</div>
											<div class="col-xs-3 pull-right text-right excluir">
												<button class="text-danger" id="exclui<?php echo $dd[$i];?>" onclick="orcamento('<?php echo $dd[$i];?>', '', 'exclui')"><i class="fa fa-trash"></i>
												</button>
											</div>

										</div>
									</div>
								</div>
							</div>
						<?php endwhile;
						else:;
						?>

						<div class="col-xs-12 produto-car" id="<?php echo $dd[$i];?>">
							<div class="col-sm-1 col-xs-3">

							</div>
							<div class="col-sm-10 col-xs-9 xx text-right">						
								<h4>Produto indisponível. <a class="text-danger" id="exclui<?php echo $dd[$i];?>" onclick="orcamento('<?php echo $dd[$i];?>', '', 'exclui')">Clique aqui <i class="fa fa-trash"></i></a></h4>
							</div>

							<div class="col-sm-2 col-xs-9 pull-right text-right excluir">
								<a class="text-danger" id="exclui<?php echo $dd[$i];?>" onclick="orcamento('<?php echo $dd[$i];?>', '', 'exclui')"><i class="fa fa-trash"></i></a>
							</div>
						</div>
						<?php
						endif;				
						wp_reset_postdata();
					}?>

					<hr>
					<div class="row">
						<div class="col-xs-12" style="margin-top:15px;">
							<hr>
							<h3>Seus dados de contato</h3>
							<form class="row form-orcamento" enctype="multipart/form-data" method="POST">
							<input type="hidden" name="action" value="finaliza_orcamento">
								<div class="col-sm-6 col-xs-12">
									<div class="form-group">
										<label>Nome <span>*</span></label>
										<input type="text" name="nome" class="form-control" placeholder="Seu nome" required>								
									</div>
									<div class="form-group">
										<label>Email <span>*</span></label>
										<input type="email" name="email" class="form-control" placeholder="Seu email" required>								
									</div>
									<?php 
									if(orcamentoConfig('orcamento-telefone')){
										?>
										<div class="form-group">
											<label>Tel <span>*</span></label>
											<input type="text" name="telefone" class="form-control" placeholder="EX (99) 99999-9999" required>							
										</div>
										<?php	
									}
									
									if(orcamentoConfig('orcamento-rg')){
										?>
										<div class="form-group">
											<label>RG <span>*</span></label>
											<input type="text" name="rg" class="form-control" placeholder="99.999.999-9" required>							
										</div>
										<?php	
									}

									if(orcamentoConfig('orcamento-cpf')){
										?>
										<div class="form-group">
											<label>CPF <span>*</span></label>
											<input type="text" name="cpf" class="form-control" placeholder="999.999.999-99" required>							
										</div>
										<?php	
									}

									if(orcamentoConfig('orcamento-cnpj')){
										?>
										<div class="form-group">
											<label>CNPJ <span>*</span></label>
											<input type="text" name="cnpj" class="form-control" placeholder="99.999.999/9999-99" required>							
										</div>
										<?php	
									}

									if(orcamentoConfig('orcamento-arquivo')){
										?>
										<div class="form-group">
											<label>Arquivo <span></span></label>
											<input type="file" name="arquivo" class="form-control">							
										</div>
										<?php	
									}
									?>
									
								</div>

								<div class="col-sm-6 col-xs-12">
									<?php 
									if(orcamentoConfig('orcamento-cep')){
										?>
										<div class="form-group">
											<label>CEP <span>*</span></label>
											<input type="text" id="cw-cep" name="cep" class="form-control" placeholder="99999-999" required>							
										</div>
										<?php	
									} 
									?>
									<div class="row">
										<div class="col-xs-12 col-sm-9">
											<?php
											if(orcamentoConfig('orcamento-rua')){
												?>
												<div class="form-group">
													<label>Rua <span>*</span></label>
													<input type="text" id="cw-rua" name="rua" class="form-control" required>							
												</div>
												<?php	
											}
											?>
										</div>
										<div class="col-xs-12 col-sm-3">
											<?php
											if(orcamentoConfig('orcamento-numero')){
												?>
												<div class="form-group">
													<label>Num. <span>*</span></label>
													<input type="text" id="cw-numero" name="numero" class="form-control" required>							
												</div>
												<?php	
											} 
											?>
										</div>
									</div>
									<?php
									if(orcamentoConfig('orcamento-bairro')){
										?>
										<div class="form-group">
											<label>bairro <span>*</span></label>
											<input type="text" id="cw-bairro" name="bairro" class="form-control" required>							
										</div>
										<?php	
									}
									?>
									<div class="row">
										<div class="col-xs-8">
											<?php
											if(orcamentoConfig('orcamento-cidade')){
												?>
												<div class="form-group">
													<label>Cidade <span>*</span></label>
													<input type="text" id="cw-cidade" name="cidade" class="form-control" required>							
												</div>
												<?php	
											}
											?>
										</div>
										<div class="col-xs-4">
											<?php
											if(orcamentoConfig('orcamento-estado')){
												?>
												<div class="form-group">
													<label>Estado <span>*</span></label>
													<select name="estado" id="cw-estado" required="" class="form-control"><option></option><option>AC</option><option>AL</option><option>AP</option><option>AM</option><option>BA</option><option>CE</option><option>DF</option><option>ES</option><option>GO</option><option>MA</option><option>MT</option><option>MS</option><option>MG</option><option>PA</option><option>PB</option><option>PR</option><option>PE</option><option>PI</option><option>RJ</option><option>RN</option><option>RS</option><option>RO</option><option>RR</option><option>SC</option><option>SP</option><option>SE</option><option>TO</option></select>						
												</div>
												<?php	
											}
											?>
										</div>
									</div>
									<div class="form-group">
										<label>Mensagem</label>
										<textarea name="mensagem" class="form-control" rows="4" placeholder="Deixe aqui sua mensagem"></textarea>
									</div>							
								</div>
								<div class="col-xs-12">
									<div class="resp-orcamento"></div>
									<div class="form-group text-center enviar">
										<div class="col-xs-12" id="resp-orcamento"></div>
										<?php 
										$config = get_option('configOrcamento');
										$orcamento_text = (orcamentoConfig('finalizacao_texto')) ? orcamentoConfig('finalizacao_texto') : 'Enviar Orçamento';
										$orcamento_back_color = orcamentoConfig('finalizacao_cor_fundo');
										$orcamento_text_color = orcamentoConfig('finalizacao_cor_texto');
										?>
										<br>
										<button type="submit" style="background-color: <?php echo $orcamento_back_color ?>; color: <?php echo $orcamento_text_color ?>" class="btn btn-lg btn-block <?php echo orcamentoConfig('finalizacao_class') ?>"><?php echo $orcamento_text ?></button>
										<br>
										<br>
										<a href="<?php echo get_option('siteUrl') ?>/produtos">Adicionar mais produtos +</a>
									</div>
									<hr>
								</div>
							</form>
						</div>
					</div>
				</div>
				<?php
			}else{
				echo "<div class='col-xs-12 text-center vazio'><h1>Sua lista de orçamento está vazia</h1><br><a href='/' class='btn btn-primary btn-lg'><i class='fa fa-reply' aria-hidden='true'></i> <b>Página inicial</b></a></div>";
			}

		}else{
			echo "<div class='col-xs-12 text-center vazio'><h1>Sua lista de orçamento está vazia</h1><br><a href='/' class='btn btn-primary btn-lg'><i class='fa fa-reply' aria-hidden='true'></i> <b>Página inicial</b></a></div>";
		}


		?>
	</div>

</div>
</section>

<?php get_footer();?> 