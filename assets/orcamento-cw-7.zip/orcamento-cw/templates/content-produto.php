<?php 
$config = get_option('configOrcamento');
$orcamento_text = (orcamentoConfig('produtos_texto')) ? orcamentoConfig('produtos_texto') : 'Orçamento';
$orcamento_back_color = orcamentoConfig('produtos_cor_fundo');
$orcamento_text_color = orcamentoConfig('produtos_cor_texto');
$conteudo .= '<div class="'.$class.' text-center produto">
	<div class="thumbnail">							
		<a href="'.get_permalink().'">															
			<table style="min-height: 170px; width:100%;">
				<tr>
					<td class="text-center">
						<img src="'.orcamento_cw_get_imgDestaque('medium').'" alt="'.get_the_title().'" title="'.get_the_title().' '.$style.'">
					</td>
				</tr>
			</table>
		</a>			
		<div class="titulo">
			<h2>'.get_the_title().'</h2>
		</div>
		<button onclick="orcamento(\''.get_the_ID().'\', \'page-produto\');" style="background-color: '.$orcamento_back_color.'; color: '.$orcamento_text_color.'" class="btn '.orcamentoConfig('produtos_class').' produto-'.get_the_ID().'">
			'.$orcamento_text.'			
		</button>
	</div>
</div>';

