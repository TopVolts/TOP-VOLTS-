<div class="row">
	<div class="col-xs-12 col-md-9">
		<?php
		global $wpdb;

		$orcamentos = $wpdb->get_results("SELECT * FROM orcamentos_cw_pedidos order by id DESC");
		if($orcamentos){
			foreach ($orcamentos as $orcamento) {
				?>
				<div class="orcamento" id="orcamento-<?php echo $orcamento->id; ?>">
					<a role="button" data-toggle="collapse" href="#collapse<?php echo $orcamento->id?>" aria-expanded="false" aria-controls="collapse<?php echo $orcamento->id?>">
						<h2>
							<i class="fa fa-chevron-down pull-right"></i> #<?php echo $orcamento->id?> <?php echo $orcamento->nomeCliente;?> <small><?php echo date('d/m/Y h:i', strtotime($orcamento->data));?></small>
						</h2>
					</a>
					<div class="collapse" id="collapse<?php echo $orcamento->id?>">
						<div class="well">
							<?php echo $orcamento->orcamento; ?>	
							<hr>
							<div class="row">
								<div class="col-xs-12 resp"></div>
								<div class="col-xs-12">
									<button class="pull-left btn-lg btn btn-success" onclick="modalResponde(<?php echo $orcamento->id?>)"><i class="fa fa-envelope-o"></i> Responder</button>
									<button class="pull-right btn-lg btn btn-danger exclui" onclick="excluiPedido(<?php echo $orcamento->id?>);"><i class="fa fa-trash"></i> Excluir</button>
								</div>
							</div>

							<?php 
							$respostas = $wpdb->get_results("SELECT * FROM orcamentos_cw_resposta WHERE id_orcamento = '$orcamento->id' order by id DESC");
							if($respostas){
								?>
								<hr>
								<h3>Respostas</h3>
								<?php
								foreach ($respostas as $resposta) {
									?>
									<a role="button" data-toggle="collapse" href="#resposta<?php echo $resposta->id?>" aria-expanded="false" aria-controls="resposta<?php echo $resposta->id?>">
										<h4 style="background-color: #7498aa;
										padding: 10px;
										color: #fff;
										margin-bottom: 0px;">
										<i class="fa fa-chevron-down pull-right"></i> Resposta em:  <?php echo date('d/m/Y h:i', strtotime($resposta->data));?>
									</h4>
								</a>
								<div class="collapse" id="resposta<?php echo $resposta->id?>">
									<div class="well">
										<?php echo $resposta->resposta; ?>
									</div>
								</div>
								<?php
							}
						}
						?>

					</div>
				</div>
			</div>
			<?php
		}
	}else{
		?>
		<div class="alert alert-warning">
			Nenhum orçamento encontrado.
		</div>
		<?php
	}

	?>
</div>
<div class="col-xs-12 col-sm-3">
	<div class="branco">
		<h2>Orçamento CW<br><small>Receba orçamentos pelo seu site WordPress</small></h2>
		<hr>
		<div id="respVersao"></div>
	</div>
</div>
</div>


<div class="modal fade" id="responde-orcamento">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title">Responder ao orçamento</h4>
			</div>
			<div class="modal-body">
				<h3>Aguarde... <i class="fa fa-spinner fa-pulse"></i></h3>
			</div>
		</div>
	</div>
</div>
