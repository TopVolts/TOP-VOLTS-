<!-- Adiciona o cabeçalho (header.php) -->
<?php get_header(); 

$ss = single_cat_title("", false);
$tituloCat = single_cat_title("", false);
?>

<section class="produtos module">
	<div class="container wrap">	
		<div class="row">
			<!-- PRODUTOS EM DESTAQUE -->
			<div class="col-sm-9 col-xs-12">
				<?php 
				the_archive_title( '<h1 class="page-title">', '</h1>' );
				the_archive_description( '<div class="taxonomy-description">', '</div>' );
				?>
				<div class="row">
					<?php 
					global $query_string;
					$paged = (get_query_var('page')) ? get_query_var('page') : 1;
					query_posts( $query_string . '&page=$paged' );	
					if (have_posts()) : while (have_posts()) : the_post();


					
					

					$class = 'col-xs-12 col-sm-6 col-md-4';
					require( plugin_dir_path( __FILE__ ).'content-produto.php');

					endwhile;
					endif;
					wp_reset_query();
					
					echo $conteudo;
					?>

					<div class="col-xs-12 orcamentos_paginacao">
						<?php echo orcamento_pagination();?>
					</div>

				</div>
			</div>
			
			<div class="col-xs-12 col-sm-3 slide-right">
				<nav class="navbar navbar-default categorias">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header col-xs-12">
						<div class="row">
							<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#categoria" aria-expanded="false">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar bar-um"></span>
								<span class="icon-bar bar-dois"></span>
								<span class="icon-bar bar-tres"></span>
							</button>
							<a class="navbar-brand" href="#">Categorias</a>
						</div>
					</div>

					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse col-xs-12" id="categoria" style="width:100%">
						<ul class="nav row">
							<?php  
							$args=array('taxonomy' => 'produto_categoria', 'post_type' => 'produto', 'orderby'=> 'title', 'order' => 'ASC');
							$categories=get_categories($args);

							foreach($categories as $category) { 
								$cat_active = ($ss == $category->name) ? 'active' : '';
								?>
								<li class="<?php echo $cat_active?>">
									<a href="/produto_categoria/<?php echo $category->slug; ?>" >
										<?php echo $category->name; ?>										
									</a>
								</li>
								<?php 
							}
							wp_reset_query(); ?>
						</ul>
					</div><!-- /.navbar-collapse -->
				</nav>
			</div>

		</div>
	</div>	
</section>


<!-- Adiciona o rodapé (footer.php) -->
<?php get_footer(); ?>