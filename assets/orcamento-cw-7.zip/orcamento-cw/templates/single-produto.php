<!-- Adiciona o cabeçalho (header.php) -->
<?php get_header(); ?>
<?php
if (have_posts()) : while (have_posts()) : the_post(); 
?>
<section class="orcamento-cw module">	
	<div class="container wrap">
		
		<div class="row">
			<div class="col-xs-12 link-topo">
				<a href="<?php echo get_home_url() ?>">Página Inicial ></i></a> <?php the_title() ?>
				<hr>
			</div>	
			<div class="col-xs-12 col-sm-7">

				<?php 
				$galeria = get_field('galeria');
				if($galeria){
					foreach ($galeria as $imagem) {
						$imageGaleria = $imagem['sizes']['large'];
						$imageThumbnail = $imagem['sizes']['thumbnail'];
						$title = $imagem['title'];

						$imgGrande .='
						<div class="swiper-slide text-center">
							<img src="'.$imageGaleria.'" alt="'.$attr.'">
						</div>';

						$miniatura .='
						<div class="swiper-slide">
							<img src="'.$imageThumbnail.'" alt="'.$attr.'">
						</div>';
					}
				}
				?>

				<div class="swiper-container gallery-top">
					<div class="swiper-wrapper">
						<div class="swiper-slide text-center">
							<img src="<?php orcamento_cw_the_imgDestaque('large') ?>" alt="<?php the_title() ?>">
						</div>
						<?php echo $imgGrande ?>
					</div>
					<!-- Add Arrows -->
					<div class="swiper-button-next"><i class="fa fa-chevron-right"></i></div>
					<div class="swiper-button-prev"><i class="fa fa-chevron-left"></i></div>
				</div>
				<div class="swiper-container gallery-thumbs">
					<div class="swiper-wrapper">
						<div class="swiper-slide">
							<img src="<?php orcamento_cw_the_imgDestaque('thumbnail'); ?>" alt="<?php the_title() ?>">
						</div>
						<?php echo $miniatura ?>
					</div>
				</div>
			</div>
			<div class="col-xs-12 col-sm-5">
				<div class="row">
					<div class="col-xs-12 col-sm-11 col-sm-offset-1">
						<h1><?php the_title() ?></h1>
						<hr>
						<?php 
						if(get_field('resumo')){
							the_field('resumo');
						}

						$config = get_option('configOrcamento');
						$orcamento_text = (orcamentoConfig('single_produto_texto')) ? orcamentoConfig('single_produto_texto') : 'Enviar Orçamento';
						$orcamento_back_color = orcamentoConfig('single_produto_cor_fundo');
						$orcamento_text_color = orcamentoConfig('single_produto_cor_texto');

						$car= (isset($_COOKIE["carrinho"])) ? $_COOKIE["carrinho"] : "";
						if(isset($_COOKIE["carrinho"]) && $car != ''){
							$array = unserialize(stripslashes($car));
						}
						
						$quantCar = ($array[$post->ID] != '') ? $array[$post->ID] : 1;
						?>
						<div class="input-group" style="padding-bottom: 15px; max-width: 150px">
							<span class="input-group-addon">Quant.</span>
							<input type="number" id="quant<?php echo $post->ID ?>" class="form-control" value="<?php echo $quantCar ?>">
						</div>
						<button style="background-color: <?php echo $orcamento_back_color ?>; color: <?php echo $orcamento_text_color ?>" class='btn btn-lg btn-block <?php echo orcamentoConfig('single_produto_class') ?> produto-<?php echo get_the_ID(); ?>' onclick="orcamento(<?php echo $post->ID ?>, 'page-produto');"><?php echo $orcamento_text ?></button>
						<br>
						<div class="compartilhe">
							<p>Compartilhe:</p>
							<div class="row">
								<div class="col-xs-4">
									<a id="comp-twitter" href="http://twitter.com/home?status=<?php the_title(); ?>+<?php the_permalink(); ?>" title="Share on Twitter" onclick="window.open(this.href,'galeria','width=680,height=470'); return false;" title="Galeria de fotos" ><i class="fa fa-twitter"></i></a>
								</div>
								<div class="col-xs-4">
									<a id="comp-facebook" href="http://www.facebook.com/share.php?u=<?php the_permalink(); ?>&title=<?php the_title(); ?>" title="Share on Facebook" onclick="window.open(this.href,'galeria','width=680,height=470'); return false;"><i class="fa fa-facebook-f"></i></a>
								</div>
								<div class="col-xs-4">
									<a id="comp-google" href="https://plus.google.com/share?url=<?php the_permalink(); ?>" title="Share on Google Plus" onclick="window.open(this.href,'galeria','width=680,height=470'); return false;"><i class="fa fa-google-plus"></i></a>
								</div>
							</div>

						</div>
					</div>
				</div>
			</div>
			<div class="col-xs-12 descricao-produto">
				<?php the_content() ?>
			</div>
			<?php 
			if(get_field('relacionados')){
				?>
				<div class="col-xs-12">
					<hr>
					<h3>Relacionados</h3>
					<div class="row">
						<?php 
						$relacionados = get_field('relacionados');
						$orcamento_text = (orcamentoConfig('produtos_texto')) ? orcamentoConfig('produtos_texto') : 'Orçamento';
						$orcamento_back_color = orcamentoConfig('produtos_cor_fundo');
						$orcamento_text_color = orcamentoConfig('produtos_cor_texto');
						$orcamento_class = orcamentoConfig('produtos_class');
						foreach( $relacionados as $post){
							setup_postdata($post); 
							$style = 'style="min-height: auto;"';

							?>
							<div class="col-xs-12 col-sm-4 col-md-3">
								<div class="thumbnail text-center">							
									<a href="<?php the_permalink()?>">															
										<table style="min-height: 190px; width:100%;">
											<tr>
												<td class="text-center">
													<img src="<?php orcamento_cw_the_imgDestaque('medium')?>" alt="<?php the_title()?>">
												</td>
											</tr>
										</table>
									</a>			
									<div class="titulo">
										<h4 style="min-height: 50px;"><?php the_title()?></h4>
									</div>
									<button onclick="orcamento('<?php echo $post->ID ?>', 'page-produto');" style="background-color: <?php echo $orcamento_back_color?>; color: <?php echo $orcamento_text_color ?>" class="<?php echo $orcamento_class ?> produto-<?php echo get_the_ID()?>">
										<?php echo $orcamento_text; ?>			
									</button>
								</div>
							</div>
							<?php
						}

						wp_reset_postdata();
						?>
					</div>
				</div>
				<?php
			}
			?>
		</div>

	</div>
</section>
<?php
endwhile;
endif;				
?>


<!-- Adiciona o rodapé (footer.php) -->
<?php get_footer(); ?>