<?php defined( 'ABSPATH' ) or die( 'No script kiddies please!' ); ?>
<div class="row">
	<div class="col-xs-12 col-sm-9">
		
		<div class="branco">

			<?php 
			$pageExiste = true;
			query_posts('post_type=page&name=orcamentos');
			if (!have_posts()){ $pageExiste = false; }
			query_posts('post_type=page&name=produtos');
			if (!have_posts()){ $pageExiste = false; } 
			if($pageExiste == false){
				?>
				<br>
				<div class="criarPagina">
					<div class="alert alert-danger text-center">

						Precisamos criar 2 página:	<b><i>/produtos</i></b> e <b><i>/orcamento</i></b><br>	
						<b>Essas páginas são necessárias para o funcionento do orçamento</b><br>		
						<br><button class="btn btn-primary btn-lg" onclick="criaPagina();"><b>Criar páginas</b></button>
						
					</div>
					<div class="resp"></div>
				</div>
				<?php
			}
			?>
			<div class="gerarShortcode">
				<h3>Gerar ShortCode Carrossel</h3>
				<p>Insira um carrossel de produtos no seu site por meio do shortcode.</p>
				<form class="row shortcode">
					<div class="col-xs-12 col-sm-7">
						<div class="input-group form-group">
							<select class="form-control" style="height: 34px;">
								<option value="">Todos os produtos</option>
								<?php 
								$args=array('taxonomy' => 'produto_categoria', 'post_type' => 'produto', 'orderby'=> 'title', 'order' => 'ASC');
								$categories=get_categories($args);

								foreach($categories as $category) { 
									?>
									<option value="<?php echo $category->slug; ?>">Categoria: <?php echo $category->name; ?></option>
									<?php 
								}
								?>
							</select>
							<span class="input-group-btn">
								<button class="btn btn-primary" type="submit">Gerar Shortcode</button>
							</span>
						</div><!-- /input-group -->
					</div>
					<div class="resp col-xs-12"></div>
				</form>
			</div>
			<br>
			<div class="alert alert-info admin">
				<p>Na página de "Produtos" use o shortcode: <span>[produtos_orcamento]<br></span></p>
				<p>Para exibir o menu de categorias use o shortcode: <span>[orcamento_menu_categorias titulo="Categorias"]<br></span></p>
			</div>

			<hr>
			<form class="configOrcamento">
				<input type="hidden" name="action" value="configOrcamento">
				<?php 
				$config = unserialize(get_option('configOrcamento'));
				?>
				<div class="branco">

					<div class="resp"></div>
					<div class="text-right">
						<button class="btn-primary btn btn-lg" type="submit" style="margin-top: 25px">Salvar</button>
					</div>
					<h3>Botões: <small>Configure as cores e texto dos botões</small></h3>

					<div class="row minicolors-theme-bootstrap" id="config-cores">
						<div class="tampa"></div>
						<div class="col-xs-12 col-sm-4">
							<h4>Botão (produtos e relacionados)</h4>
							<div class="form-group">
								<label>Cor Fundo</label><br>
								<input type="text" name="produtos_cor_fundo" class="color form-control" value="<?php echo $config['produtos_cor_fundo'] ?>">
							</div>

							<div class="form-group">
								<label>Cor Texto</label><br>
								<input type="text" name="produtos_cor_texto" class="color form-control" value="<?php echo $config['produtos_cor_texto'] ?>">
							</div>

							<div class="form-group">
								<label>Texto</label>
								<input type="text" name="produtos_texto" class="form-control" placeholder="Pedir Orçamento" value="<?php echo $config['produtos_texto'] ?>">
							</div>
							<div class="form-group">
								<label>Class (atributo) <i class="fa fa-info-circle text-info" data-toggle="tooltip" data-placement="top" title="Class fixa: 'btn'"></i></label>
								<input type="text" name="produtos_class" class="form-control" value="<?php echo $config['produtos_class'] ?>">
							</div>
						</div>
						<div class="col-xs-12 col-sm-4">
							<h4>Botão (page do produto)</h4>
							<div class="form-group">
								<label>Cor Fundo</label><br>
								<input type="text" name="single_produto_cor_fundo" class="color form-control" value="<?php echo $config['single_produto_cor_fundo'] ?>">
							</div>

							<div class="form-group">
								<label>Cor Texto</label><br>
								<input type="text" name="single_produto_cor_texto" class="color form-control" value="<?php echo $config['single_produto_cor_texto'] ?>">
							</div>

							<div class="form-group">
								<label>Texto</label>
								<input type="text" name="single_produto_texto" class="form-control" placeholder="Pedir Orçamento" value="<?php echo $config['single_produto_texto'] ?>">
							</div>
							<div class="form-group">
								<label>Class (atributo) <i class="fa fa-info-circle text-info" data-toggle="tooltip" data-placement="top" title="Class fixa: 'btn btn-lg btn-block'"></i></label>
								<input type="text" name="single_produto_class" class="form-control" value="<?php echo $config['single_produto_class'] ?>">
							</div>
						</div>
						<div class="col-xs-12 col-sm-4">
							<h4>Botão (página de finalização)</h4>
							<div class="form-group">
								<label>Cor Fundo</label><br>
								<input type="text" name="finalizacao_cor_fundo" class="color form-control" value="<?php echo $config['finalizacao_cor_fundo'] ?>">
							</div>

							<div class="form-group">
								<label>Cor Texto</label><br>
								<input type="text" name="finalizacao_cor_texto" class="color form-control" value="<?php echo $config['finalizacao_cor_texto'] ?>">
							</div>

							<div class="form-group">
								<label>Texto</label>
								<input type="text" name="finalizacao_texto" class="form-control" placeholder="Enviar Orçamento" value="<?php echo $config['finalizacao_texto'] ?>">
							</div>
							<div class="form-group">
								<label>Class (atributo) <i class="fa fa-info-circle text-info" data-toggle="tooltip" data-placement="top" title="Class fixa: 'btn btn-lg btn-block'"></i></label>
								<input type="text" name="finalizacao_class" class="form-control" value="<?php echo $config['finalizacao_class'] ?>">
							</div>
						</div>
					</div>
				</div>
				<br>
				<div class="branco">
					<h3>Dados do cliente: <small>Selecione quais informações deseja solicitar na finalização</small></h3>
					<hr>
					<div class="row">
						<div class="col-xs-12 col-sm-6">
							<h4>Dados pessoais</h4>
							<div class="form-group">
								<div class="checkbox">
									<label>
										<input type="checkbox" class="form-control" checked disabled> Nome (padrão)
									</label>
								</div>
							</div>
							<div class="form-group">
								<div class="checkbox">
									<label>
										<input type="checkbox" class="form-control" checked disabled> Email (padrão)
									</label>
								</div>
							</div>
							<div class="form-group">
								<div class="checkbox">
									<label>
										<input type="checkbox" class="form-control" checked disabled> Mensagem (padrão)
									</label>
								</div>
							</div>
							<div class="form-group">
								<div class="checkbox">
									<label>
										<input type="checkbox" name="orcamento-telefone" <?php if($config['orcamento-telefone']){echo 'checked';} ?> class="form-control" checked> Telefone
									</label>
								</div>
							</div>
							<div class="form-group">
								<div class="checkbox">
									<label>
										<input type="checkbox" <?php if($config['orcamento-rg']){echo 'checked';} ?> name="orcamento-rg" class="form-control"> RG
									</label>
								</div>
							</div>
							<div class="form-group">
								<div class="checkbox">
									<label>
										<input type="checkbox" <?php if($config['orcamento-cpf']){echo 'checked';} ?> name="orcamento-cpf" class="form-control"> CPF
									</label>
								</div>
							</div>
							<div class="form-group">
								<div class="checkbox">
									<label>
										<input type="checkbox" <?php if($config['orcamento-cnpj']){echo 'checked';} ?> name="orcamento-cnpj" class="form-control"> CNPJ
									</label>
								</div>
							</div>
							<div class="form-group">
								<div class="checkbox">
									<label>
										<input type="checkbox" <?php if($config['orcamento-arquivo']){echo 'checked';} ?> name="orcamento-arquivo" class="form-control"> Aquivo
									</label>
								</div>
							</div>

						</div>
						<div class="col-xs-12 col-sm-6">
							<h4>Endereço</h4>
							<div class="form-group">
								<div class="checkbox">
									<label>
										<input type="checkbox" <?php if($config['orcamento-cep']){echo 'checked';} ?> name="orcamento-cep" class="form-control">  CEP
									</label>
								</div>
							</div>
							<div class="form-group">
								<div class="checkbox">
									<label>
										<input type="checkbox" <?php if($config['orcamento-rua']){echo 'checked';} ?> name="orcamento-rua" class="form-control"> Rua
									</label>
								</div>
							</div>
							<div class="form-group">
								<div class="checkbox">
									<label>
										<input type="checkbox" <?php if($config['orcamento-numero']){echo 'checked';} ?> name="orcamento-numero" class="form-control"> Número
									</label>
								</div>
							</div>
							<div class="form-group">
								<div class="checkbox">
									<label>
										<input type="checkbox" <?php if($config['orcamento-bairro']){echo 'checked';} ?> name="orcamento-bairro" class="form-control"> Bairro
									</label>
								</div>
							</div>
							<div class="form-group">
								<div class="checkbox">
									<label>
										<input type="checkbox" <?php if($config['orcamento-cidade']){echo 'checked';} ?> name="orcamento-cidade" class="form-control"> Cidade
									</label>
								</div>
							</div>
							<div class="form-group">
								<div class="checkbox">
									<label>
										<input type="checkbox" <?php if($config['orcamento-estado']){echo 'checked';} ?> name="orcamento-estado" class="form-control"> Estado
									</label>
								</div>
							</div>
						</div>
						<div class="col-xs-12">
							<hr>
							<?php print_footer_scripts(); ?>
							<h3>Configuração de resposta</h3>
							<p>Configuração do conteúdo de resposta ao cliente. Use os <a data-toggle="modal" href='#cw_shortcodes'><b>cw_shortcodes</b></a> para inserir conteúdos variáveis.</p>
							<?php 
							$mensagemPadrao = "<h3>Olá <b>[cw_nomeCliente]</b></h3>
							<p><b>Seu orçamento:</b></p>
							[cw_listaProdutos]
							<br>
							<h4>Resposta ao orçamento:</h4>
							(<span style='color:red'>escreva aqui a resposta</span>)
							<hr>
							<p><b>Atenciosamente</b></p>
							<p>[cw_nomeSite]</p>
							<p>[cw_siteUrl]</p>";
							$mensagem = ($config['resposta_orcamento'] != '') ? $config['resposta_orcamento'] : $mensagemPadrao;
							
							$args = array(
								'tinymce'       => array(
									'toolbar1'      => ''
									),
								'quicktags'     => true,
								'textarea_rows' => 15,
								'media_buttons' => false
								);
								?>
								<div class="form-group">
									<?php echo bc_get_wp_editor(nl2br($mensagem), 'resposta_orcamento', $args);?>
								</div>
								<div class="alert alert-warning"><b>Atenção:</b> Salve pelo menos 2 vezes para garantir as alterações.</div>
								<div class="modal fade" id="cw_shortcodes">
									<div class="modal-dialog">
										<div class="modal-content">
											<div class="modal-header">
												<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
												<h4 class="modal-title">CW_SHORTCODES</h4>
											</div>
											<div class="modal-body">


												<div class="input-group">
													<input class="form-control" id="cw_nomeCliente" value="[cw_nomeCliente]">
													<span class="input-group-btn">
														<button type="button" class="btn btn-info" onclick="copiarShortcode('#cw_nomeCliente')">Copiar</button>
													</span>
												</div>
												<p>Exibe o nome do cliente.</p>
												<br>

												<div class="input-group">
													<input class="form-control" id="cw_listaProdutos" value="[cw_listaProdutos]">
													<span class="input-group-btn">
														<button type="button" class="btn btn-info" onclick="copiarShortcode('#cw_listaProdutos')">Copiar</button>
													</span>
												</div>
												<p>Exibe a lista com os produtos que o cliente pediu para orçar.</p>
												<br>

												<div class="input-group">
													<input class="form-control" id="cw_nomeSite" value="[cw_nomeSite]">
													<span class="input-group-btn">
														<button type="button" class="btn btn-info" onclick="copiarShortcode('#cw_nomeSite')">Copiar</button>
													</span>
												</div>
												<p>Exibe o nome do site (<i><?php echo get_option('blogname') ?>)</i></p>
												<br>

												<div class="input-group">
													<input class="form-control" id="cw_siteUrl" value="[cw_siteUrl]">
													<span class="input-group-btn">
														<button type="button" class="btn btn-info" onclick="copiarShortcode('#cw_siteUrl')">Copiar</button>
													</span>
												</div>
												<p>Exibe a url do site (<i><?php echo get_option('siteUrl') ?></i>)</p>
											</div>
											<div class="modal-footer">
												<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-xs-12">
								<div class="resp"></div>
								<div class="form-group text-right">
									<button class="btn-primary btn btn-lg" type="submit">Salvar</button>
								</div>
							</div>
						</div>

					</div>


				</div>
			</form>
		</div>
		<div class="col-xs-12 col-sm-3">
			<div class="branco">
				<h2>Orçamento CW<br><small>Receba orçamentos pelo seu site WordPress</small></h2>
				<hr>
				<div id="respVersao"></div>
			</div>
		</div>
	</div>
