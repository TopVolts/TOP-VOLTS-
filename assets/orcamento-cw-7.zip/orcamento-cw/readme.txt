﻿=== Orçamento CW ===
Contributors: Naldo_almeida
Donate link: http://cicloneweb.com.br/doacao
Tags: carrinho de orçamento, orçamentos wordpress, orcamento, sistema de orçamento, produtos, bootstrap
Requires at least: 3.0.1
Tested up to: 4.9.2
Requires PHP: 5.6
Stable tag: 1.3.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
 
Transforme seu site em um catalogo online. Sistema para captação de orçamentos.
 
== Description ==
 
Agora ficou fácil receber orçamentos através do seu site wordpress. 
Com o "Orçamento CW" você consegue criar produtos ou serviços no seu site e disponibilizar uma forma simples e fácil para seus clientes solicitarem orçamentos. 
 
== Installation ==
 
e.g.
1.3.6 -- Edição do aconteûdo padrao de resposta ao cliente
1.3.5 -- Quantidade de produtos por página no shortcode [produtos_orcamento]
1.3.4 -- função de loading do submit do form de resposta
1.3.3 -- Resposta pelo painel e exclusão do orçamento
1.3.0 -- Guarda orçamento no banco de dados. 
1.2.0 -- Inclusão do campo para upload de arquivo

 
1. Upload 'orcamento-cw/' to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
 



 